<?php 
$db->ConnectionClose();
?>