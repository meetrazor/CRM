<?php
$asset_css = array(
    'data-tables/responsive/css/datatables.responsive',
    'css/chosen.create-option',
    'bootstrap-daterangepicker/daterangepicker',
);

$asset_js = array(
    'js/chosen.jquery.min',
    'js/chosen.create-option.jquery',
    'bootstrap-datepicker/js/bootstrap-datepicker',
    'bootstrap-daterangepicker/date',
    'bootstrap-daterangepicker/daterangepicker',
);
include_once 'header.php';
$teleCallerDd = $db->CreateOptions('html', 'admin_user', array('user_id','concat(first_name," ",last_name)'), null, array('concat(first_name," ",last_name)'=>"asc"),"user_type = ".UT_TC."");
$cityDd = $db->CreateOptions('html', 'city', array('city_id','city_name'), null, array('city_name'=>"asc"));
$dispositionDd = $db->CreateOptions("html","disposition_master",array("disposition_id","disposition_name"),null,array("disposition_name"=>"asc"));
$campaignDd = $db->CreateOptions("html", "campaign_master", array("campaign_id", "campaign_name"), null, array("campaign_name" => "asc"));
$categoryDd = $db->CreateOptions("html","category_master",array("category_id","category_name"),null,array("category_name"=>"asc"));
?>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    </script>



    <script type="text/javascript">

    var brOptions;
    var nrOptions;

    $(function() {

        $(".chzn-select,.chzn-select-nr,.chzn-select-dis,.chzn-select-cam").chosen({
            allow_single_deselect:true
        })

        $(".chzn-select").change(function(){
            cityChart();
        })

        $(".chzn-select-nr").change(function(){
            telecallerChart();
        })


        $(".chzn-select-dis").change(function(){
            dispositionChart();
        })

        $(".chzn-select-cam").change(function(){
            campaignChart();
        })



        if (jQuery().daterangepicker) {
            $(".date-picker").daterangepicker(
                {
                    ranges : {
                        Today : [ "today", "today" ],
                        Yesterday : [ "yesterday", "yesterday" ],
                        "Last 7 Days" : [ Date.today().add({
                            days : -6
                        }), "today" ],
                        "Last 30 Days" : [ Date.today().add({
                            days : -29
                        }), "today" ],
                        "This Month" : [
                            Date.today().moveToFirstDayOfMonth(),
                            Date.today().moveToLastDayOfMonth() ],
                        "Last Month" : [
                            Date.today().moveToFirstDayOfMonth()
                                .add({
                                    months : -1
                                }),
                            Date.today().moveToFirstDayOfMonth()
                                .add({
                                    days : -1
                                }) ]
                    },
                    opens : "left",
                    format : "dd-MM-yyyy",
                    separator : " to ",
                    locale : {
                        applyLabel : "Submit",
                        fromLabel : "From",
                        toLabel : "To",
                        customRangeLabel : "Custom Range",
                        daysOfWeek : [ "Su", "Mo", "Tu", "We", "Th",
                            "Fr", "Sa" ],
                        monthNames : [ "January", "February", "March",
                            "April", "May", "June", "July",
                            "August", "September", "October",
                            "November", "December" ],
                        firstDay : 1
                    },
                    buttonClasses : [ "btn-danger" ]
                },
                function(e, t) {
                    $(this).val(e.toString("dd-MM-yyyy") + " : " + t.toString("dd-MM-yyyy"));
                    cityChart();
                });

            $(".date-picker-tr").daterangepicker(
                {
                    ranges : {
                        Today : [ "today", "today" ],
                        Yesterday : [ "yesterday", "yesterday" ],
                        "Last 7 Days" : [ Date.today().add({
                            days : -6
                        }), "today" ],
                        "Last 30 Days" : [ Date.today().add({
                            days : -29
                        }), "today" ],
                        "This Month" : [
                            Date.today().moveToFirstDayOfMonth(),
                            Date.today().moveToLastDayOfMonth() ],
                        "Last Month" : [
                            Date.today().moveToFirstDayOfMonth()
                                .add({
                                    months : -1
                                }),
                            Date.today().moveToFirstDayOfMonth()
                                .add({
                                    days : -1
                                }) ]
                    },
                    opens : "right",
                    format : "dd-MM-yyyy",
                    separator : " to ",
                    locale : {
                        applyLabel : "Submit",
                        fromLabel : "From",
                        toLabel : "To",
                        customRangeLabel : "Custom Range",
                        daysOfWeek : [ "Su", "Mo", "Tu", "We", "Th",
                            "Fr", "Sa" ],
                        monthNames : [ "January", "February", "March",
                            "April", "May", "June", "July",
                            "August", "September", "October",
                            "November", "December" ],
                        firstDay : 1
                    },
                    buttonClasses : [ "btn-danger" ]
                },
                function(e, t) {
                    $(this).val(e.toString("dd-MM-yyyy") + " : " + t.toString("dd-MM-yyyy"));
                    telecallerChart()
                });


            $(".date-picker-lead").daterangepicker(
                {
                    ranges : {
                        Today : [ "today", "today" ],
                        Yesterday : [ "yesterday", "yesterday" ],
                        "Last 7 Days" : [ Date.today().add({
                            days : -6
                        }), "today" ],
                        "Last 30 Days" : [ Date.today().add({
                            days : -29
                        }), "today" ],
                        "This Month" : [
                            Date.today().moveToFirstDayOfMonth(),
                            Date.today().moveToLastDayOfMonth() ],
                        "Last Month" : [
                            Date.today().moveToFirstDayOfMonth()
                                .add({
                                    months : -1
                                }),
                            Date.today().moveToFirstDayOfMonth()
                                .add({
                                    days : -1
                                }) ]
                    },
                    opens : "right",
                    format : "dd-MM-yyyy",
                    separator : " to ",
                    locale : {
                        applyLabel : "Submit",
                        fromLabel : "From",
                        toLabel : "To",
                        customRangeLabel : "Custom Range",
                        daysOfWeek : [ "Su", "Mo", "Tu", "We", "Th",
                            "Fr", "Sa" ],
                        monthNames : [ "January", "February", "March",
                            "April", "May", "June", "July",
                            "August", "September", "October",
                            "November", "December" ],
                        firstDay : 1
                    },
                    buttonClasses : [ "btn-danger" ]
                },
                function(e, t) {
                    $(this).val(e.toString("dd-MM-yyyy") + " : " + t.toString("dd-MM-yyyy"));
                    leadChart();
                });

            $(".date-picker-disposition").daterangepicker(
                {
                    ranges : {
                        Today : [ "today", "today" ],
                        Yesterday : [ "yesterday", "yesterday" ],
                        "Last 7 Days" : [ Date.today().add({
                            days : -6
                        }), "today" ],
                        "Last 30 Days" : [ Date.today().add({
                            days : -29
                        }), "today" ],
                        "This Month" : [
                            Date.today().moveToFirstDayOfMonth(),
                            Date.today().moveToLastDayOfMonth() ],
                        "Last Month" : [
                            Date.today().moveToFirstDayOfMonth()
                                .add({
                                    months : -1
                                }),
                            Date.today().moveToFirstDayOfMonth()
                                .add({
                                    days : -1
                                }) ]
                    },
                    opens : "right",
                    format : "dd-MM-yyyy",
                    separator : " to ",
                    locale : {
                        applyLabel : "Submit",
                        fromLabel : "From",
                        toLabel : "To",
                        customRangeLabel : "Custom Range",
                        daysOfWeek : [ "Su", "Mo", "Tu", "We", "Th",
                            "Fr", "Sa" ],
                        monthNames : [ "January", "February", "March",
                            "April", "May", "June", "July",
                            "August", "September", "October",
                            "November", "December" ],
                        firstDay : 1
                    },
                    buttonClasses : [ "btn-danger" ]
                },
                function(e, t) {
                    $(this).val(e.toString("dd-MM-yyyy") + " : " + t.toString("dd-MM-yyyy"));
                    dispositionChart();
                });
        }


        $(".clear").click(function(){
            $(this).closest("td").find(".input-large").val("");
            if($(this).closest("td").find(".input-large").attr("id") == "date_range_lead"){
                leadChart();
            }else if($(this).closest("td").find(".input-large").attr("id") == "date_range_city"){
                cityChart();
            } else if($(this).closest("td").find(".input-large").attr("id") == "date_range_disposition"){
                dispositionChart();
            } else {
                telecallerChart();
            }

            return false;
        });

        cityChart();
        telecallerChart();
        leadChart();
        dispositionChart();
        campaignChart();

    });


    function telecallerChart(){
        $.ajax({
            type: 'post',
            url: "control/report.php?act=telecaller",
            data: {
                "tele_caller_id": $('#tele_caller_id').val(),
                "campaign_id": $('#t_campaign_id').val(),
                "category_id": $('#t_category_id').val(),
                "city_id": $('#t_city_id').val(),
                "date": $('.date-picker-tr').val(),
            },
            dataType: 'json',
            success: function (data) {
                drawTelecallerChart(data);
            }
        })
    }

    function drawTelecallerChart(data) {


        if(data.success){


            chartData = data.report_data;

            // console.log(tableData);
//                    console.log(chartData);

            // console.log(tableData);
            console.log(chartData);

            var arr = [['City','Transaction Made','Prospect To Lead']];
            arr = arr.concat(chartData);

            var data = google.visualization.arrayToDataTable(arr);

            var options = {
                chart: {
                    title: 'Tele Caller Wise Performance',
                }
            };


            var chart = new google.visualization.ColumnChart(document.getElementById('telecaller_chart_div'));

            chart.draw(data, options);

        }

    }


    function cityChart() {

        $.ajax({
            type: 'post',
            url: "control/report.php?act=cityreport",
            data: {
                "city_id": $('#city_id').val(),
                "campaign_id": $('#a_campaign_id').val(),
                "category_id": $('#a_category_id').val(),
                "date": $('.date-picker').val(),
            },
            dataType: 'json',
            success: function (data) {
                drawCityChart(data);
            }
        })
    }

    function drawCityChart(data) {


        if(data.success){


            chartData = data.report_data;

            // console.log(tableData);
//                    console.log(chartData);

            // console.log(tableData);
            console.log(chartData);

            var arr = [['City','Prospect','Leads','Transaction Made']];
            arr = arr.concat(chartData);

            var data = google.visualization.arrayToDataTable(arr);

            var options = {
                chart: {
                    title: 'Area Wise Performance',
                }
            };


            var chart = new google.visualization.ColumnChart(document.getElementById('area_div'));

            chart.draw(data, options);

        }

    }

    function leadChart() {

        $.ajax({
            type: 'post',
            url: "control/report.php?act=leadreport",
            data: {
                "date": $('.date-picker-lead').val(),
            },
            dataType: 'json',
            success: function (data) {
                drawLeadChart(data);
            }
        })
    }

    function drawLeadChart(data) {


        if(data.success){


            chartData = data.report_data;

            // console.log(tableData);
//                    console.log(chartData);

            // console.log(tableData);
            console.log(chartData);

            var arr = [['Parameter','Count']];
            arr = arr.concat(chartData);

            var data = google.visualization.arrayToDataTable(arr);

            var options = {
                chart: {
                    title: 'Prospect to Lead',
                }
            };


            var chart = new google.visualization.ColumnChart(document.getElementById('lead_div'));

            chart.draw(data, options);

        }

    }

    function dispositionChart() {

        $.ajax({
            type: 'post',
            url: "control/report.php?act=dispositionreport",
            data: {
                "disposition_id": $('#d_disposition_id').val(),
                "campaign_id": $('#d_campaign_id').val(),
                "date": $('.date-picker-disposition').val(),
            },
            dataType: 'json',
            success: function (data) {
                drawDispositionChart(data);
            }
        })
    }

    function drawDispositionChart(data) {


        if(data.success){


            chartData = data.report_data;

            // console.log(tableData);
//                    console.log(chartData);

            // console.log(tableData);
            console.log(chartData);

            var arr = [['Disposition','Count']];
            arr = arr.concat(chartData);

            var data = google.visualization.arrayToDataTable(arr);

            var options = {
                chart: {
                    title: 'Disposition Counts',
                }
            };


            var chart = new google.visualization.ColumnChart(document.getElementById('disposition_div'));

            chart.draw(data, options);

        }

    }


    function campaignChart() {

        $.ajax({
            type: 'post',
            url: "control/report.php?act=campaignreport",
            data: {
                "campaign_id": $('#c_campaign_id').val(),
            },
            dataType: 'json',
            success: function (data) {
                drawCampaignChart(data);
            }
        })
    }

    function drawCampaignChart(data) {


        if(data.success){


            chartData = data.report_data;

            // console.log(tableData);
//                    console.log(chartData);

            // console.log(tableData);
            console.log(chartData);

            var arr = [['Campaign','Total Prospect']];
            arr = arr.concat(chartData);

            var data = google.visualization.arrayToDataTable(arr);

            var options = {
                chart: {
                    title: 'Campaign Performance',
                }
            };


            var chart = new google.visualization.ColumnChart(document.getElementById('campaign_div'));

            chart.draw(data, options);

        }

    }

    </script>
<?php
if($acl->IsAllowed($login_id,'REPORT', 'REPORT', 'View BD Report')){
    ?>
<div class="row-fluid">
    <div class='span12'>
        <div class="span4" onclick="location.href='prospect.php';">
            <div class="center">
                <span class="btn btn-large btn-primary no-hover" style="width: 200px">

                    <span class="bigger-75" id='new_prospect'>
                        <?php echo Utility::userCount("prospect"); ?>
                    </span>

                    <br>
                    <span class="smaller-70" id=''>Today New Prospect</span>
                </span>
            </div>
        </div>
        <div class="span4" onclick="location.href='activity.php';">
            <div class="center">
                <span class="btn btn-large btn-primary no-hover" style="width: 200px">

                    <span class="bigger-75" id='new_prospect'>
                        <?php echo Utility::userCount('follow_up_balance'); ?>
                    </span>

                    <br>
                    <span class="smaller-70" id=''>Today Follow up</span>
                </span>
            </div>
        </div>
        <div class="span4" onclick="location.href='activity.php';">
            <div class="center">
                <span class="btn btn-large btn-primary no-hover" style="width: 200px">

                    <span class="bigger-75" id='call'>
                        <?php echo Utility::userCount("lead_count","lm.created_at = '".ONLY_DATE_YMD."'"); ?>
                    </span>

                    <br>
                    <span class="smaller-70" id=''>Today Lead</span>
                </span>
            </div>
        </div>
    </div>
</div>
    <hr>
<div class="row-fluid">
    <div class='span12'>
        <div class="span4"  onclick="location.href='activity.php';">
            <div class="center">
                <span class="btn btn-large btn-primary no-hover" style="width: 200px">

                    <span class="bigger-75" id='new_prospect'>
                        <?php echo Utility::userCount("prospect",'1=1'); ?>
                    </span>

                    <br>
                    <span class="smaller-70" id=''>Till Date Prospects</span>
                </span>
            </div>
        </div>
        <div class="span4" onclick="location.href='activity.php';">
            <div class="center">
                <span class="btn btn-large btn-primary no-hover" style="width: 200px">

                    <span class="bigger-75" id='new_prospect'>
                        <?php echo Utility::userCount("balance_prospect"); ?>
                    </span>

                    <br>
                    <span class="smaller-70" id=''>Prospects to be called </span>
                </span>
            </div>
        </div>

        <div class="span4" onclick="location.href='lead.php';">
            <div class="center">
                <span class="btn btn-large btn-primary no-hover" style="width: 200px">

                    <span class="bigger-75" id='total_lead'>
                        <?php echo Utility::userCount("lead_count"); ?>
                    </span>

                    <br>
                    <span class="smaller-70" id=''>Total Lead</span>
                </span>
            </div>
        </div>

    </div>
</div>

    <div class="row-fluid">
        <div class="span12">

            <div class="row-fluid">
                <div class="span12 widget-container-span ui-sortable">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5>Prospect To Lead</h5>

                        </div>

                        <div class="widget-body">
                            <div class="widget-main">
                                <form id="frm_report_lead" class="form-inline" name="frm_account_filter">
                                    <table id="">
                                        <tr>
                                            <td colspan="">
                                                <label for="subject" class="">Select Date</label>
                                                <label>
                                                    <div class='row-fluid input-append'>
                                                        <input class='input-large date-picker-lead' data-placement='top' type='text'
                                                               placeholder='Select Date'
                                                               name='filter[date]' id="date_range_lead" data-date-format='dd-mm-yyyy'
                                                               readonly='readonly'>
                                                        <span class='add-on'><i class='icon-calendar'></i></span>
                                                        <span for='filter[date]' class='help-inline'></span>
                                                    </div>
                                                </label>
                                                <label>
                                                    <input type="button" value="clear" class="btn btn-mini btn-info clear">
                                                </label>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                                <div id="lead_div"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row-fluid">
                <div class="span12 widget-container-span ui-sortable">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5>TeleCaller Performance</h5>

                        </div>

                        <div class="widget-body">
                            <div class="widget-main">
                                <form id="frm_report_filter" class="form-inline" name="frm_account_filter">
                                    <table id="filter_table">

                                        <tr>
                                            <td>
                                                <label for="subject" class="">City</label>
                                                <div class="controls">
                                                    <select name="t_city_id" id="t_city_id" class="chzn-select-nr" data-placeholder="select City">
                                                        <option></option>
                                                        <?php echo $cityDd; ?>
                                                    </select>
                                                </div>
                                            </td>
                                            <td>
                                                <label for="subject" class="">Telecaller</label>
                                                <div class="controls">
                                                    <select name="tele_caller_id" id="tele_caller_id" class="chzn-select-nr" data-placeholder="select telecaller">
                                                        <option></option>
                                                        <?php echo $teleCallerDd; ?>
                                                    </select>
                                                </div>
                                            </td>
                                            <td>
                                                <label for="subject" class="">Campaign</label>
                                                <div class="controls">
                                                    <select name="t_campaign_id" id="t_campaign_id" class="chzn-select-nr" data-placeholder="select Campaign">
                                                        <option></option>
                                                        <?php echo $campaignDd; ?>
                                                    </select>
                                                </div>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <label for="subject" class="">Loan/Product Type</label>
                                                <div class="controls">
                                                    <select name="t_category_id" id="t_category_id" class="chzn-select-nr" data-placeholder="select loan/product">
                                                        <option></option>
                                                        <?php echo $categoryDd; ?>
                                                    </select>
                                                </div>
                                            </td>
                                            <td colspan="">
                                                <label for="subject" class="">Select Date</label>
                                                <div class="controls inline">
                                                    <div class='row-fluid input-append'>
                                                        <input class='input-large date-picker-tr' data-placement='top' type='text'
                                                               placeholder='Select Date'
                                                               name='filter[date]' id="nr_date_range" data-date-format='dd-mm-yyyy'
                                                               readonly='readonly'>
                                                        <span class='add-on'><i class='icon-calendar'></i></span>
                                                        <span for='filter[date]' class='help-inline'></span>
                                                    </div>
                                                </div>
                                                <label class="inline">
                                                    <input type="button" value="clear" class="btn btn-mini btn-info clear">
                                                </label>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                                <div id="telecaller_chart_div"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row-fluid">
                <div class="span12 widget-container-span ui-sortable">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5>Area Wise Performance</h5>

                        </div>

                        <div class="widget-body">
                            <div class="widget-main">
                                <form id="frm_report_filter" class="form-inline" name="frm_account_filter">
                                    <table id="">

                                        <tr>
                                            <td>
                                                <label for="subject" class="">Select City</label>
                                                <label>
                                                    <select name="city_id" id="city_id" class="chzn-select" data-placeholder="select City">
                                                        <option></option>
                                                        <?php echo $cityDd; ?>
                                                    </select>
                                                </label>
                                            </td>

                                            <td>
                                                <label for="subject" class="">Select Campaign</label>
                                                <label>
                                                    <select name="a_campaign_id" id="a_campaign_id" class="chzn-select" data-placeholder="select Campaign">
                                                        <option></option>
                                                        <?php echo $campaignDd; ?>
                                                    </select>
                                                </label>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <label for="subject" class="">Loan/Product Type</label>
                                                <label>
                                                    <select name="a_category_id" id="a_category_id" class="chzn-select" data-placeholder="select loan/product">
                                                        <option></option>
                                                        <?php echo $categoryDd; ?>
                                                    </select>
                                                </label>
                                            </td>
                                            <td colspan="">
                                                <label for="subject" class="">Select Date</label>
                                                <label>
                                                    <div class='row-fluid input-append'>
                                                        <input class='input-large date-picker' data-placement='top' type='text'
                                                               placeholder='Select Date'
                                                               name='filter[date]' id="date_range_city" data-date-format='dd-mm-yyyy'
                                                               readonly='readonly'>
                                                        <span class='add-on'><i class='icon-calendar'></i></span>
                                                        <span for='filter[date]' class='help-inline'></span>
                                                    </div>
                                                </label>
                                                <label>
                                                    <input type="button" value="clear" class="btn btn-mini btn-info clear">
                                                </label>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                                <div id="area_div"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row-fluid">
                <div class="span12 widget-container-span ui-sortable">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5>Disposition Wise Performance</h5>

                        </div>

                        <div class="widget-body">
                            <div class="widget-main">
                                <form id="frm_disposition_filter" class="form-inline" name="frm_account_filter">
                                    <table id="">

                                        <tr>
                                            <td>
                                                <label for="subject" class="">Select Disposition</label>
                                                <label>
                                                    <select name="d_disposition_id" id="d_disposition_id"  class="chzn-select-dis" data-placeholder="select Disposition">
                                                        <option></option>
                                                        <?php echo $dispositionDd; ?>
                                                    </select>
                                                </label>
                                            </td>
                                            <td>
                                                <label for="subject" class="">Select Campaign</label>
                                                <label>
                                                    <select name="d_campaign_id" id="d_campaign_id" class="chzn-select-dis" data-placeholder="select Campaign">
                                                        <option></option>
                                                        <?php echo $campaignDd; ?>
                                                    </select>
                                                </label>
                                            </td>
                                            <td colspan="">
                                                <label for="subject" class="">Select Date</label>
                                                <label>
                                                    <div class='row-fluid input-append'>
                                                        <input class='input-large date-picker-disposition' data-placement='top' type='text'
                                                               placeholder='Select Date'
                                                               name='filter[date]' id="date_range_disposition"" data-date-format='dd-mm-yyyy'
                                                               readonly='readonly'>
                                                        <span class='add-on'><i class='icon-calendar'></i></span>
                                                        <span for='filter[date]' class='help-inline'></span>
                                                    </div>
                                                </label>
                                                <label>
                                                    <input type="button" value="clear" class="btn btn-mini btn-info clear">
                                                </label>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                                <div id="disposition_div"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row-fluid">
                <div class="span12 widget-container-span ui-sortable">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5>Campaign Wise Performance</h5>

                        </div>

                        <div class="widget-body">
                            <div class="widget-main">
                                <form id="frm_campaign_filter" class="form-inline" name="frm_campaign_filter">
                                    <table id="">

                                        <tr>

                                            <td>
                                                <label for="subject" class="">Select Campaign</label>
                                                <label>
                                                    <select name="c_campaign_id" id="c_campaign_id" class="chzn-select-cam" data-placeholder="select Campaign">
                                                        <option></option>
                                                        <?php echo $campaignDd; ?>
                                                    </select>
                                                </label>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                                <div id="campaign_div"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>

        <?php } ?>
<?php 
include_once 'footer.php';
?>