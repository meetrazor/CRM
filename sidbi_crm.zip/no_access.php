<?php
include_once 'header.php';
?>
<div class="row-fluid">
	<div class="span12">
		<!--PAGE CONTENT BEGINS-->

		<div class="error-container">
			<div class="well">
				<h1 class="grey lighter smaller">Access Denied</h1>

				<hr>
				<h3 class="lighter smaller">You don't have permission to access this section!</h3>
				<!-- 
				<div class="row-fluid">
					<div class="center">
						<a class="btn btn-grey" href="#">
							<i class="icon-arrow-left"></i>
							Go Back
						</a>

					</div>
				</div>
				 -->
			</div>
		</div><!--PAGE CONTENT ENDS-->
	</div><!--/.span-->
</div>				
<?php 
include_once 'footer.php';
?>