<?php

echo phpinfo();

?>